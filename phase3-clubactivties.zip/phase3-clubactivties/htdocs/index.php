<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");

require_once 'config/database.php';

$db = (new Database())->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$uri = explode("/", trim($_SERVER['REQUEST_URI'], "/"));

if (isset($uri[1]) && $uri[1] === 'items') {
    switch ($method) {
        case 'GET':
            include 'controller/get_item.php';
            break;
        case 'POST':
            include 'controller/create_item.php';
            break;
        case 'PUT':
            include 'controller/update_item.php';
            break;
        case 'DELETE':
            include 'controller/delete_item.php';
            break;
        default:
            http_response_code(405);
            echo json_encode(["error" => "Method Not Allowed"]);
    }
} else {
    http_response_code(404);
    echo json_encode(["error" => "Not Found"]);
}
<?php
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing 'id' field"]);
    exit;
}

$query = "DELETE FROM items WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $data->id);
$stmt->execute();

echo json_encode(["message" => "Item deleted successfully"]);
?>

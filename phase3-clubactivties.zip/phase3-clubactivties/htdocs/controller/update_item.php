<?php
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id) || !isset($data->name)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing 'id' or 'name' field"]);
    exit;
}

$query = "UPDATE items SET name = :name, description = :description WHERE id = :id";
$stmt = $db->prepare($query);
$stmt->bindParam(':name', $data->name);
$stmt->bindParam(':description', $data->description);
$stmt->bindParam(':id', $data->id);
$stmt->execute();

echo json_encode(["message" => "Item updated successfully"]);
?>


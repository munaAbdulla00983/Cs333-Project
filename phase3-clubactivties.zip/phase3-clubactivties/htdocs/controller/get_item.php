<?php
$query = "SELECT * FROM items ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($items);
?>

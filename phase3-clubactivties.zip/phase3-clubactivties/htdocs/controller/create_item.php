<?php
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->name)) {
    http_response_code(400);
    echo json_encode(["error" => "Missing 'name' field"]);
    exit;
}

$query = "INSERT INTO items (name, description) VALUES (:name, :description)";
$stmt = $db->prepare($query);
$stmt->bindParam(':name', $data->name);
$stmt->bindParam(':description', $data->description);
$stmt->execute();

http_response_code(201);
echo json_encode(["message" => "Item created successfully"]);
?>
